var net = require('net');

var client = new net.Socket();
client.connect(8081, '127.0.0.1', function() {
	console.log('Connection established');
});


client.on('close', function() {
	console.log('Connection closed');
});